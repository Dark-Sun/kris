# -*- encoding : utf-8 -*-
require 'test_helper'

class SessionsHelperTest < ActionView::TestCase
end
