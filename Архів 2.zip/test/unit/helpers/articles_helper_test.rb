# -*- encoding : utf-8 -*-
require 'test_helper'

class ArticlesHelperTest < ActionView::TestCase
end
