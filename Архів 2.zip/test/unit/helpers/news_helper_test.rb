# -*- encoding : utf-8 -*-
require 'test_helper'

class NewsHelperTest < ActionView::TestCase
end
