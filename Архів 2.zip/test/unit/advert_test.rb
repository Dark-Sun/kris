# -*- encoding : utf-8 -*-
require 'test_helper'

class AdvertTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
