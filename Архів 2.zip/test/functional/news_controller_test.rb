# -*- encoding : utf-8 -*-
require 'test_helper'

class NewsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
