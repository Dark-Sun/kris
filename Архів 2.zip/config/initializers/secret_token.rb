# -*- encoding : utf-8 -*-
# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Kris::Application.config.secret_token = '3edc4bc5170c8d2e2ac2ca98acbd3a3b6a989e5ed599b486e22fb65a921b898bf8c8da579a6c30d0cac1d2c58a5e279691a2f2582c1c36738591651524530470'
